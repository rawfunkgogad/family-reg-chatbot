"""
신청서 양식 첨부문서(PDF/HWP) 다운로드 및 기재요령 텍스트 추출 검증 테스트
- 법정 기본 신고서식(출생·혼인·이혼·사망·개명 등 34종) 및 별지 제11호 서식 파싱 검증
- 서식 후면 '작성 방법' 핵심 실무 지침(인명용한자 5자 제한, 24시각제, 증인 서명 등) 무결성 검증
"""
import sys
import json
from pathlib import Path

# Add backend directory to sys.path
backend_dir = Path(__file__).parent.parent / "backend"
sys.path.insert(0, str(backend_dir))

DATA_FILE = backend_dir / "data" / "efamily_customer_center.json"
TEMPLATES_DIR = backend_dir / "data" / "form_templates"

def test_form_templates_cached_files():
    """다운로드된 로컬 서식 파일 캐시 검증"""
    assert TEMPLATES_DIR.exists(), f"Templates dir not found: {TEMPLATES_DIR}"
    files = list(TEMPLATES_DIR.glob("*.*"))
    assert len(files) >= 34, f"Expected at least 34 form files, found {len(files)}"
    
    file_names = [f.name for f in files]
    assert any("출생신고서.pdf" in fn for fn in file_names), "출생신고서.pdf not found in cache"
    assert any("혼인신고서.pdf" in fn for fn in file_names), "혼인신고서.pdf not found in cache"
    assert any("개명신고서.pdf" in fn for fn in file_names), "개명신고서.pdf not found in cache"
    assert any("제11호" in fn and ".hwp" in fn for fn in file_names), "별지 제11호 서식.hwp not found in cache"
    print(f"PASS: test_form_templates_cached_files ({len(files)} form templates cached locally)")

def test_extracted_form_instructions():
    """서식 후면 상세 작성방법 및 기재요령 텍스트 검증"""
    assert DATA_FILE.exists()
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    forms = [d for d in data.get("documents", []) if d.get("category") == "가족관계등록 신청서식"]
    
    # 1. 출생신고서 작성요령 검증
    birth_form = next((f for f in forms if "출생신고서" in f["title"]), None)
    assert birth_form is not None, "Birth form document not found"
    assert birth_form.get("has_attachment_text") is True
    birth_cts = birth_form.get("content", "")
    assert "인명용 한자" in birth_cts, "Expected '인명용 한자' in birth form instructions"
    assert "5" in birth_cts, "Expected '5자' limit in birth form instructions"
    assert "24" in birth_cts or "시각제" in birth_cts, "Expected '24시각제' in birth form instructions"
    print("  [PASS] 출생신고서: 인명용한자 5자 제한 및 24시각제 표기요령 추출 검증 완료.")

    # 2. 혼인신고서 작성요령 검증
    marriage_form = next((f for f in forms if "혼인신고서" in f["title"]), None)
    assert marriage_form is not None
    assert marriage_form.get("has_attachment_text") is True
    m_cts = marriage_form.get("content", "")
    assert "증인" in m_cts or "등록기준지" in m_cts or "성명" in m_cts
    print("  [PASS] 혼인신고서: 증인 및 당사자 기재요령 추출 검증 완료.")

    # 3. 별지 제11호 서식 (가족관계등록사항별 증명서 교부 등 신청서) 검증
    cert_form = next((f for f in forms if "별지 제11호" in f["title"]), None)
    assert cert_form is not None
    assert cert_form.get("has_attachment_text") is True
    c_cts = cert_form.get("content", "")
    assert "교부" in c_cts or "증명서" in c_cts or "신청" in c_cts
    print("  [PASS] 별지 제11호 서식: HWP 본문 기재항목 추출 검증 완료.")

    print("PASS: test_extracted_form_instructions (All key form guidelines verified)")

if __name__ == "__main__":
    print("=== [Form Attachment Crawler & Text Extraction Tests Starting] ===")
    test_form_templates_cached_files()
    test_extracted_form_instructions()
    print("\nALL FORM ATTACHMENT EXTRACTION TESTS PASSED! (100%)")
