import json
from pathlib import Path

CORPUS_DIR = Path(__file__).parent.parent / "backend" / "data" / "corpus"

def test_corpus_files_exist():
    efamily_file = CORPUS_DIR / "efamily_scourt_guide_corpus.json"
    easylaw_file = CORPUS_DIR / "easylaw_family_reg_corpus.json"
    integrated_file = CORPUS_DIR / "integrated_family_reg_tdm_corpus.json"

    assert efamily_file.exists(), "efamily_scourt_guide_corpus.json should exist"
    assert easylaw_file.exists(), "easylaw_family_reg_corpus.json should exist"
    assert integrated_file.exists(), "integrated_family_reg_tdm_corpus.json should exist"

    assert efamily_file.stat().st_size > 50000, "efamily corpus should be > 50KB"
    assert easylaw_file.stat().st_size > 100000, "easylaw corpus should be > 100KB"
    assert integrated_file.stat().st_size > 150000, "integrated corpus should be > 150KB"

def test_integrated_corpus_schema_and_content():
    integrated_file = CORPUS_DIR / "integrated_family_reg_tdm_corpus.json"
    with open(integrated_file, "r", encoding="utf-8") as f:
        docs = json.load(f)

    assert len(docs) >= 150, f"Expected at least 150 documents, got {len(docs)}"

    seen_ids = set()
    articles_count = 0
    qa_count = 0

    for idx, d in enumerate(docs):
        # Required fields
        for field in ["id", "title", "category", "source", "content", "metadata"]:
            assert field in d, f"Document #{idx} missing '{field}'"
            assert d[field], f"Document #{idx} '{field}' is empty"

        # Unique IDs
        assert d["id"] not in seen_ids, f"Duplicate ID: {d['id']}"
        seen_ids.add(d["id"])

        # Content length
        assert len(d["content"]) >= 25, f"Content too short in {d['id']}"

        # Source URL
        assert "source_url" in d["metadata"], f"Missing source_url in {d['id']}"

        if d.get("detected_articles"):
            articles_count += 1
        if d.get("qa_pair"):
            qa_count += 1

    assert articles_count > 50, f"Expected at least 50 documents with detected articles, got {articles_count}"
    print(f"\n[Test Summary] Total docs: {len(docs)}, Articles tagged: {articles_count}, QA pairs: {qa_count}")

if __name__ == "__main__":
    print("[Testing] test_corpus_files_exist...")
    test_corpus_files_exist()
    print("[Testing] test_integrated_corpus_schema_and_content...")
    test_integrated_corpus_schema_and_content()
    print("\n>>> ALL TDM CORPUS TESTS PASSED! <<<")
