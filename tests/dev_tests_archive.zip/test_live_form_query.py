import requests
import json
import sys

# Ensure UTF-8 output on Windows console
if sys.stdout.encoding != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def test_live_chat_query():
    payload = {
        "messages": [
            {"role": "user", "content": "출생신고서 작성 시 한자 이름은 몇 자까지 지을 수 있으며, 출생시각은 어떻게 기재해야 하나요?"}
        ],
        "use_rag": True,
        "bypass_cache": True
    }

    with requests.post("http://127.0.0.1:8000/api/chat", json=payload, stream=True, timeout=60) as resp:
        assert resp.status_code == 200, f"HTTP status {resp.status_code}"
        sources = []
        deltas = []
        for line in resp.iter_lines():
            if not line:
                continue
            line_str = line.decode("utf-8")
            if line_str.startswith("data: "):
                content = line_str[6:].strip()
                if content == "[DONE]":
                    break
                try:
                    ev = json.loads(content)
                    t = ev.get("type")
                    d = ev.get("data")
                    if t == "sources":
                        sources = d
                    elif t == "delta":
                        deltas.append(d)
                except Exception:
                    pass

        full_answer = "".join(deltas)
        print("=== Retrieved Sources ===")
        for s in sources[:4]:
            print(f"- {s.get('title')} (score: {s.get('score')})")

        print("\n=== Generated Answer ===")
        print(full_answer)

        # Assertions
        assert len(sources) > 0, "No sources retrieved"
        # Check if 출생신고서 or 인명용 한자 is present in sources or answer
        source_titles = [s.get("title", "") for s in sources]
        has_birth_form = any("출생신고서" in t or "출생" in t for t in source_titles)
        print(f"\nHas birth form in sources: {has_birth_form}")
        
        # Check content keywords
        assert "5자" in full_answer or "인명용" in full_answer or "한자" in full_answer or "24시" in full_answer or "출생" in full_answer, "Relevant keywords missing"
        print("\n[PASS] Live chat query successfully utilized form guidelines!")

if __name__ == "__main__":
    test_live_chat_query()
